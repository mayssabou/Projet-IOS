//
//  DAMProjApp.swift
//  DAMProj
//
//  Created by Apple Esprit on 6/11/2024.
//

import SwiftUI

@main
struct DAMProjApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
